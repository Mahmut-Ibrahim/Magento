package storemanager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-21-4:53 PM
 */
public class NewRootCategoryFormPage {

    private WebDriver driver;
    private String useFullName;

    public By categoryInformationTabs = By.xpath("//*[@id='category_info_tabs']/li");

    public NewRootCategoryFormPage(WebDriver driver) {
        this.driver = driver;
    }

    public String getUseFullName() {
        return useFullName;
    }

    public void setUseFullName(String useFullName) {
        this.useFullName = useFullName;
    }

    private By nameField = By.cssSelector("#group_4name");
    private By isActiveDropDown = By.cssSelector("#group_4is_active");
    private By descriptionField = By.cssSelector("#group_4description");
    private By pageTitleField = By.cssSelector("#group_4meta_title");
    private By metaKeywordsField = By.cssSelector("#group_4meta_keywords");
    private By metaDescriptionField = By.cssSelector("#group_4meta_description");
    private By saveButton = By.cssSelector(".scalable.save");
    private By successMessage = By.xpath("//*[@id='messages']//span");
    private By generalInformationForm = By.cssSelector("#category_tab_content");
    private By includeInNavigationMenuDropDown = By.cssSelector("#group_4include_in_menu");
    private By deleteButton = By.cssSelector(".scalable.delete");


    public void fillGeneralInformationForm(String name, String section, String description, String pageTitle,
                                           String metaKeywords, String metaDescription) {
        driver.findElement(nameField).sendKeys(name);
        setUseFullName(name);
        Select select = new Select(driver.findElement(isActiveDropDown));
        select.selectByVisibleText(section);
        driver.findElement(descriptionField).sendKeys(description);
        driver.findElement(pageTitleField).sendKeys(pageTitle);
        driver.findElement(metaKeywordsField).sendKeys(metaKeywords);
        driver.findElement(metaDescriptionField).sendKeys(metaDescription);
    }

    public void clickSaveButton() {
        driver.findElement(saveButton).click();
    }

    public String getSuccessMessage() {
        return driver.findElement(successMessage).getText();
    }

    public boolean verifyCreatedCategory() {
        WebElement cratedCategory = driver.findElement(By.xpath("//div[@class='categories-side-col']//span[contains(text(),'" + getUseFullName() + "')]"));
        return cratedCategory.isDisplayed();
    }

    public boolean verifyGeneralInformationForm() {
        return (driver.findElement(generalInformationForm)).isDisplayed();
    }

    public void clickOnCategoryFolder() {
        WebElement cratedCategory = driver.findElement(By.xpath("//div[@class='categories-side-col']//span[contains(text(),'" + getUseFullName() + "')]"));
        cratedCategory.click();
    }

    public void selectNoInIncludeInNavigationMenu() {
        Select select = new Select(driver.findElement(includeInNavigationMenuDropDown));
        select.selectByVisibleText("No");
    }

    public void clickOnDeleteButton() {
        driver.findElement(deleteButton).click();
    }

}
