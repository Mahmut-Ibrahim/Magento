package storemanager;

import factory.DriverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-18-9:33 PM
 */
public class LoginPage {

    private WebDriver driver;

    //1. By locators
    private By userName = By.id("username");
    private By password = By.id("login");
    private By loginButton = By.cssSelector(".form-button");
    private By forgotPasswordLink = By.linkText("Forgot your password?");

    //2. Construct of the page class
    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    //3. page action

    public boolean isForgotPasswordLinkExist() {
        return DriverFactory.getDriver().findElement(forgotPasswordLink).isDisplayed();
    }

    public void enterUserName(String username) {
        driver.findElement(userName).sendKeys(username);
    }

    public void enterPassword(String pwd) {
        driver.findElement(password).sendKeys(pwd);
    }

    public void clickOnLogin() {
        driver.findElement(loginButton).click();
    }

    public ManageCurrencyRatesPage doLogin(String un, String pwd){
        driver.findElement(userName).sendKeys(un);
        driver.findElement(password).sendKeys(pwd);
        driver.findElement(loginButton).click();
        return new ManageCurrencyRatesPage(driver);
    }
}
