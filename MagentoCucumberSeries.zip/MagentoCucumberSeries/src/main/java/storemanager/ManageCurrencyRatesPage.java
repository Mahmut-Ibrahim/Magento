package storemanager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-20-6:04 PM
 */
public class ManageCurrencyRatesPage {

    private WebDriver driver;

    public By tabSections = By.xpath("//*[@id='nav']/li/a/span");

    public By catalogTabSections = By.xpath("//*[contains(text(),'Catalog')]/ancestor::li/ul/li");

    public ManageCurrencyRatesPage(WebDriver driver) {
        this.driver = driver;
       // PageFactory.initElements(driver, this);
    }
}
