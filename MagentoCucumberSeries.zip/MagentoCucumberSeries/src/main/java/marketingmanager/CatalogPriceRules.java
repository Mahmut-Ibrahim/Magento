package marketingmanager;

import factory.DriverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;
import java.util.Random;

/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-27-9:42 AM
 */
public class CatalogPriceRules {
    private WebDriver driver;
    private String idNumber;
    private String ruleName;

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public CatalogPriceRules(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "#promo_catalog_grid_filter_rule_id")
    WebElement idField;

    @FindBy(css = "#promo_catalog_grid_filter_name")
    WebElement ruleNameField;

    @FindBy(xpath = "//*[@title='Search']")
    WebElement searchButton;

    @FindBy(xpath = "//*[@title='Reset Filter']")
    WebElement resetFilterButton;

    public void selectsOneIdNumberRandomly() {
        Random random = new Random();
        List<WebElement> listInSections = DriverFactory.getDriver().findElements(By.xpath("//*[@class='data']/tbody/tr/td[1]"));
        while (true) {
            int list = random.nextInt(listInSections.size());
            String selectedId = listInSections.get(list).getText();
            if (Integer.parseInt(selectedId) >= 10) {
                setIdNumber(selectedId);
                System.out.println("This is a selected Rule Name: " + selectedId);
                break;
            }
        }
    }

    public void fillIdToField() {
        idField.sendKeys(getIdNumber());
    }

    public void clickOnSearchButton() {
        searchButton.click();
    }

    public String getFieldValue() {
        return idField.getAttribute("value");
    }

    public String listIdNumber() {
        WebElement numberOnList = driver.findElement(By.xpath("//*[@class='data']//tbody//td[1][contains(.,'" + getIdNumber() + "')]"));
        return numberOnList.getText();
    }

    public void clickOnResetButton() {
        resetFilterButton.click();
    }

    public void selectsOneRuleNameRandomly() {
        Random random = new Random();
        List<WebElement> listInSections = DriverFactory.getDriver().findElements(By.xpath("//*[@class='data']/tbody/tr/td[2]"));
        int list = random.nextInt(listInSections.size());
        String selectedRuleName = listInSections.get(list).getText();


        setRuleName(selectedRuleName);
        System.out.println("This is a selected Rule Name: " + selectedRuleName);
    }

    public void fillNameToField() {
        ruleNameField.sendKeys(getRuleName());
    }

    public String getNameFieldValue() {
        return ruleNameField.getAttribute("value");
    }

    public String listRuleName() {
        WebElement nameOnList = driver.findElement(By.xpath("//*[@class='data']//tbody//td[2][contains(.,'" + getRuleName() + "')]"));
        return nameOnList.getText();
    }

}
