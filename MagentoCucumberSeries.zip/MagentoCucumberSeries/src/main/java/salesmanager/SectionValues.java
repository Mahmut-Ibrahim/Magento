package salesmanager;

/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-28-7:46 PM
 */
public enum SectionValues {
    Pending,Processing
}
