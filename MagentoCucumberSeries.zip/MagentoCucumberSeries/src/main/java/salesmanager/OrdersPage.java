package salesmanager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import pageutilitu.Utility;

import java.util.*;

/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-28-12:43 PM
 */
public class OrdersPage {

    private WebDriver driver;

    public OrdersPage(WebDriver driver) {
        this.driver = driver;
    }


    public void selectPendingOrProcessingRandomly(){
        int idx = new Random().nextInt(SectionValues.values().length);
        Select status = new Select(driver.findElement(By.cssSelector("#sales_order_grid_filter_status")));
        status.selectByVisibleText(String.valueOf(SectionValues.values()[idx]));
    }
    
    public void clickOnAnyOrder(){
        Utility.randomSelect("//*[@class='data']/tbody/tr");
    }
}
