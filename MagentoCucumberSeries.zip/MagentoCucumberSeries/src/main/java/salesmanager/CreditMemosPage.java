package salesmanager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-28-12:45 PM
 */
public class CreditMemosPage {
    private WebDriver driver;
    private String memosNumber;


    public CreditMemosPage(WebDriver driver) {
        this.driver = driver;
    }

    public String getMemosNumber() {
        return memosNumber;
    }

    public void setMemosNumber(String memosNumber) {
        this.memosNumber = memosNumber;
    }

    public void getNumber(){
        WebElement number = driver.findElement(By.xpath("//*[@class='wrapper']//*[@class='icon-head head-sales-order-invoice']"));
        System.out.println("Order number is: " + number.getText());
        System.out.println("Order number is: " + number.getText().replace("New Invoice for Order #",""));
        setMemosNumber(number.getText().replace("New Invoice for Order #",""));
    }
    
    public void fillNumberField(){
        WebElement orderField = driver.findElement(By.cssSelector("#sales_creditmemo_grid_filter_order_increment_id"));
        orderField.sendKeys(getMemosNumber());
    }


    public boolean verifyCanSeeCreditMemos(){
        WebElement valueOfOrderField = driver.findElement(By.cssSelector("#sales_creditmemo_grid_filter_order_increment_id"));
        WebElement creditMemosListTable = driver.findElement(By.cssSelector("#sales_creditmemo_grid_table tbody"));
        return creditMemosListTable.getText().contains(valueOfOrderField.getAttribute("value"));
    }

}
