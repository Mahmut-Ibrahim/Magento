package stepdefinitions;

import factory.DriverFactory;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import pageutilitu.ExcelReader;
import pageutilitu.Utility;
import storemanager.LoginPage;
import storemanager.ManageCurrencyRatesPage;
import storemanager.NewRootCategoryFormPage;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-20-6:02 PM
 */
public class ManageCurrencyRatesSteps {
    private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
    private NewRootCategoryFormPage formPage = new NewRootCategoryFormPage(DriverFactory.getDriver());
    private ManageCurrencyRatesPage manageCurrencyRatesPage;

    @Given("user has already logged in to application")
    public void userHasAlreadyLoggedInToApplication(DataTable credTable) {
        List<Map<String, String>> credList = credTable.asMaps();
        String userName = credList.get(0).get("username");
        String password = credList.get(0).get("password");

        DriverFactory.getDriver().get("http://magentoqa2.unitedcoder.com/index.php/admin");
        manageCurrencyRatesPage = loginPage.doLogin(userName, password);
    }

    @Given("user on the Home page")
    public void userInManageCurrencyRatesPage() {
        String title = Utility.getPageTitle();
        System.out.println("Home page title is: " + title);
    }

    @Then("user gets the menu tab list on the home page")
    public void userGetsTabSection(DataTable sectionsTable) {
        List<String> pageSections = sectionsTable.asList();
        System.out.println("Expected page tabs sections: " + pageSections);

        List<String> actualTabSectionList = Utility.getElementsText(manageCurrencyRatesPage.tabSections);
        System.out.println("Actual page tabs sections: " + actualTabSectionList);

        Assert.assertTrue(pageSections.containsAll(actualTabSectionList));
    }


    @And("home page tab section count should be {int}")
    public void tabSectionCountShouldBe(int expectedSectionCount) {
        Assert.assertEquals(Utility.getSectionCount(manageCurrencyRatesPage.tabSections), expectedSectionCount);
    }

    @When("user hovers to click the {string}")
    public void userHoversOverThe(String text) {
        DriverFactory.getDriver().manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Utility.hoverToClick(text);
    }

    @Then("user gets the list under the Catalog tab")
    public void userGetsCatalogTabSection(DataTable sectionsTable) {
        List<String> pageSections = sectionsTable.asList();
        System.out.println("Expected Catalog tabs sections: " + pageSections);

        List<String> actualTabSectionList = Utility.getElementsText(manageCurrencyRatesPage.catalogTabSections);
        System.out.println("Actual Catalog tabs sections: " + actualTabSectionList);

        Assert.assertTrue(pageSections.containsAll(actualTabSectionList));
    }

    @And("Catalog list count should be {int}")
    public void catalogTabSSectionCountShouldBe(int expectedSectionCount) {
        Assert.assertEquals(Utility.getSectionCount(manageCurrencyRatesPage.catalogTabSections), expectedSectionCount);
    }


    @Then("user navigates to {string}")
    public void userNavigatesToPageAndShouldSeePageName(String expectedPageName) {
        System.out.println("Expected page name: " + expectedPageName);
        System.out.println("Actual page name: " + Utility.getPageName(expectedPageName));

        Assert.assertEquals(expectedPageName, Utility.getPageName(expectedPageName));
    }

    @And("user gets Category Information tabs")
    public void userGetsCategoryInformationTabs(DataTable sectionsTable) {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        List<String> infoTabSections = sectionsTable.asList();
        System.out.println("Expected Category Information tabs sections: " + infoTabSections);

        List<String> actualInfoTabSectionList = Utility.getElementsText(formPage.categoryInformationTabs);
        System.out.println("Actual Category Information tabs sections: " + actualInfoTabSectionList);

        Assert.assertTrue(infoTabSections.containsAll(actualInfoTabSectionList));
    }


    @And("Category Information tabs count should be {int}")
    public void categoryInformationTabsCountShouldBe(int expectedSectionCount) {
        Assert.assertEquals(Utility.getSectionCount(formPage.categoryInformationTabs), expectedSectionCount);
    }

    @And("user should be able to see General Information form")
    public void userSeesForm() {
        Assert.assertTrue(formPage.verifyGeneralInformationForm());
    }

    @When("user fills the form given sheet name {string} and row number {int}")
    public void userFillsTheFormGivenSheetNameAndRowNumberRowNumber(String sheetName, Integer rowNumber) throws IOException, InvalidFormatException {
        ExcelReader reader = new ExcelReader();
        List<Map<String, String>> testData = reader.getData("/Users/kadir/IdeaProjects/MagentoCucumberSeries/Test_Data/DataForMagento.xlsx", sheetName);

        String name = testData.get(rowNumber).get("Name");
        String Yes_No = testData.get(rowNumber).get("IsActive");
        String description = testData.get(rowNumber).get("Description");
        String pageTitle = testData.get(rowNumber).get("Page Title");
        String metaKeywords = testData.get(rowNumber).get("Meta Keywords");
        String metaDescription = testData.get(rowNumber).get("Meta Description");

        formPage.fillGeneralInformationForm(name + System.currentTimeMillis(), Yes_No, description, pageTitle, metaKeywords, metaDescription);

    }

    @When("user clicks on Save Category button")
    public void userClicksOnButton() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        formPage.clickSaveButton();
    }

    @Then("user should be able to see success message {string}")
    public void itShowsASuccessfulMessage(String expectedSuccessMessage) {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String message = formPage.getSuccessMessage();
        System.out.println("This is success message: " + message);
        Assert.assertEquals(formPage.getSuccessMessage(), expectedSuccessMessage);
    }

    @And("user should be able to see New Category folder in the left Categories Side Column")
    public void userSeesNewCategoryFolderInTheLeftCategoriesSideColumn() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Assert.assertTrue(formPage.verifyCreatedCategory());
    }

    @When("user clicks on new Category")
    public void userClicksOnNewCategoryWhichCreatedBeforeForEditing() {
        formPage.clickOnCategoryFolder();
    }

    @And("user changes any field on the form")
    public void userChangesAnyFieldOnTheForm() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        formPage.selectNoInIncludeInNavigationMenu();
    }

    @And("user clicks on Delete Category button")
    public void userClicksOnDeleteCategoryButton() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        formPage.clickOnDeleteButton();
    }

    @And("user clicks on the OK button from an alert pop up")
    public void userClicksOnTheOKButtonFromAnAlertPopUp() {
        Utility.waitForAlertIsPresent();
        Utility.handleAlert();
    }

}
