package stepdefinitions;


import factory.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import pageutilitu.Utility;
import storemanager.LoginPage;

/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-19-5:51 PM
 */
public class LoginSteps {

    private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
    private static String title;

    @Given("user is on login page")
    public void user_is_on_login_page() {
        DriverFactory.getDriver().get("http://magentoqa2.unitedcoder.com/index.php/admin");
    }

    @When("user gets the title of the page")
    public void user_gets_the_title_of_the_page() {
        title = Utility.getPageTitle();
        System.out.println("Page title is: " + LoginSteps.title);
    }

    @Then("page title should be {string}")
    public void page_title_should_be(String expectedTitleName) {
        Assert.assertTrue(title.contains(expectedTitleName));
    }


    @Then("Forgot your password link should be displayed")
    public void forgotYourPasswordLinkShouldBeDisplayed() {
        Assert.assertTrue(loginPage.isForgotPasswordLinkExist());
    }

    @When("user enter username {string}")
    public void userEnterUsername(String userName) {
        loginPage.enterUserName(userName);
    }

    @And("user enters password {string}")
    public void userEntersPassword(String password) {
        loginPage.enterPassword(password);
    }

    @And("user clicks on Login button")
    public void userClicksOnLoginButton() {
        loginPage.clickOnLogin();
    }
}
