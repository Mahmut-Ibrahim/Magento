package stepdefinitions;

import factory.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import pageutilitu.Utility;
import salesmanager.CreditMemosPage;
import salesmanager.OrdersPage;

import java.util.concurrent.TimeUnit;

/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-28-12:42 PM
 */
public class SalesSteps {

    private OrdersPage ordersPage = new OrdersPage(DriverFactory.getDriver());
    private CreditMemosPage creditMemosPage = new CreditMemosPage(DriverFactory.getDriver());

    @When("user selects Pending or Processing sections in Status drop down")
    public void userSelectsPendingOrProcessingSectionsInStatusDropDown() {
        ordersPage.selectPendingOrProcessingRandomly();
    }

    @And("user clicks on {string} button")
    public void userClicksOnButton(String buttonName) {
        DriverFactory.getDriver().manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Utility.clickOnButton(buttonName);
    }

    @And("user clicks on any order in the list table")
    public void userClicksOnAnyOrderInTheListTable() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ordersPage.clickOnAnyOrder();
    }

    @Given("user navigates to {string} page")
    public void userNavigatesToPage(String pageName) {
        String name = Utility.getPageNameH3(pageName);
        System.out.println("Page name is: " + name);
    }

    @And("user gets the Credit Memos number on the table")
    public void userGetsTheCreditMemosNumberInTable() {
        creditMemosPage.getNumber();
    }

    @When("user enters order number in the Order field")
    public void userFillsTheCreditMemosNumberInCreditMemosFieldColumn() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        creditMemosPage.fillNumberField();
    }

    @Then("user should be able to see new Credit Memos in the table list")
    public void userShouldBeAbleToSeeNewCreditMemosInTheTableList() {
        Assert.assertTrue(creditMemosPage.verifyCanSeeCreditMemos());
    }

}
