package stepdefinitions;

import factory.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import marketingmanager.CatalogPriceRules;
import org.junit.Assert;

/**
 * @author Kadirdan Abdukerim
 * @create 2022-07-27-9:40 AM
 */
public class MarketingSteps {

    private CatalogPriceRules catalogPriceRules = new CatalogPriceRules(DriverFactory.getDriver());

    @When("user selects one id number randomly in ID column on the list table")
    public void userSelectsOneIdNumberRandomlyInIDColumnOnTheListTable() {
        catalogPriceRules.selectsOneIdNumberRandomly();
    }

    @And("user enters the random ID number in the ID field")
    public void userFillsTheNumberInIDFieldWithMadeTheRandomIdNumber() {
        catalogPriceRules.fillIdToField();
    }

    @And("user Clicks on Search button")
    public void userClicksOnSearchButton() {
        catalogPriceRules.clickOnSearchButton();
    }

    @Then("user should be able to see Rules ID should match the selected ID")
    public void userShouldBeAbleToSeeRulesIDMatchWithSelectedID() {
        Assert.assertEquals(catalogPriceRules.listIdNumber(), catalogPriceRules.getFieldValue());

        System.out.println("Id field value is: " + catalogPriceRules.getFieldValue());
        System.out.println("Table's ID is: " + catalogPriceRules.listIdNumber());
    }

    @When("user clicks on Reset Filter button")
    public void userClicksOnResetFilterButton() {
        catalogPriceRules.clickOnResetButton();
    }

    @When("user selects one rule name randomly in Rule Name column on the list table")
    public void userSelectsOneRuleNameRandomlyInRuleNameColumnOnTheListTable() {
        catalogPriceRules.selectsOneRuleNameRandomly();
    }

    @And("user enters random Rule Name in the Rule Name field")
    public void userFillsTheRuleNameFieldWithMadeTheRandomRuleName() {
        catalogPriceRules.fillNameToField();
    }

    @Then("user should be able to see Rule Name should match the selected Rule Name")
    public void userShouldBeAbleToSeeRulesRuleNameMatchWithSelectedRuleName() {
        Assert.assertEquals(catalogPriceRules.listRuleName(), catalogPriceRules.getNameFieldValue());

        System.out.println("Rule name field value is: " + catalogPriceRules.getNameFieldValue());
        System.out.println("Table's rule name is: " + catalogPriceRules.listRuleName());
    }
}
